# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.



from .text_block import TextBlock

ContentBlock = TextBlock
